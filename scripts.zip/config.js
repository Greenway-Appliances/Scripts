module.exports = {
  // mongoURL: "mongodb://localhost:27017/sankara", //local
  mongoURL: "mongodb://anto.raphael:antoraphael@10.0.140.199:17273/?authMechanism=DEFAULT&authSource=greenwayFullfilmentTest" //test development
  // mongoURL: "mongodb://super_admin:admin%402023@1.22.214.75:27017/Sankara-Dev", //test development
  // mongoURL: "mongodb://super_admin:admin%402023@1.22.214.75:27017/Sankara-QA", //live development
  // mongoURL: "mongodb://UATAdmin:sanakarauat2023@15.207.6.229:27017/Sankara-UAT", // client dev
  // mongoURL:
  // "mongodb://PRODAdmin:sanakaraprod2023@3.7.246.84:27017/Sankara-PROD", // client live
};
