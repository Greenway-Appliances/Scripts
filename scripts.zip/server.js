const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");
const app = express();
const keys = require("./config");
const bodyParser = require("body-parser");
const Leads = require("./models/lead");
const Customers = require("./models/customer");
const Orders = require("./models/order");

app.use(cors("*"));
app.use(express.json());
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

app.get('/', async (req,res)=>{
  console.log("hit")

  // res.send('hi')
  let orders = await Orders.find().limit(10)
  console.log("orders", orders)
  res.send(orders)
})

app.listen(3000)
// mongo connection
mongoose.connect(keys.mongoURL, {
  useNewUrlParser: true,
  useUnifiedTopology: true,
});
mongoose.set("strictQuery", false);

const connection = mongoose.connection;
connection.on("error", (error) => {
  console.log("MongoDB connection error", error);
});
connection.on("open", () => {
  console.log("MongoDB connected");
});
console.log("connection", connection);

// router url

// app.use("/auth", auth);
// app.use("/mobile", TokenVerification, mobile);
// app.use("/web", TokenVerification, web);

// // run live  port
// app.listen(4001, () => {
//   console.log("server connected on 4001");
// });

// run testing port
// app.listen(4000, () => {
//   console.log("server connected on 4000");
// });
